package com.DAO;

import com.entity.lib;

public interface libDAO {

	public boolean addtolib(lib l );
}
